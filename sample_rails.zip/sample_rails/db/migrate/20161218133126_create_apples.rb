class CreateApples < ActiveRecord::Migration
  def change
    create_table :apples do |t|
    end
  end
end
